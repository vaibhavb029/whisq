
(function ( $ ) {

	$(function() {
      // The DOM is ready!
      // The rest of your code goes here!
    if(slider_options) {
    	$.each(slider_options, function(index, value) {
    		
    		$(value.element).textSlider(value.settings);
    	})
   	}
  	});
}(jQuery));